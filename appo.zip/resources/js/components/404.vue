<template>
    <div>
        <b-container>
            <div class="card">
                <div class="card-header">
                    <div class="card-title">
                        <span class="text-center">All Reports </span>
                    </div>
                </div>
                <div class="card-body">
                    <h2> 404 </h2>
                </div>
            </div>
        </b-container>
    </div>
</template>

<script>
    export default {
        
    }
</script>
